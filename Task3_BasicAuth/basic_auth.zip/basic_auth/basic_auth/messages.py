class Message:
    LOGIN_INVALID = "Invalid Username and Password"
    LOGIN_MISSING_FIELDS = "Missing Username and Password"
    LOGIN_USER_DISABLED = "Disabled Account"
    SIGNUP_MISSING_FIELDS = "Please fill out all the fields"