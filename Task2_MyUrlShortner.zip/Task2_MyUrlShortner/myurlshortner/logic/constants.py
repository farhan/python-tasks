# DOMAIN_NAME = 'http://myurlshortener.com/'
DOMAIN_NAME = 'http://localhost:8000/'
